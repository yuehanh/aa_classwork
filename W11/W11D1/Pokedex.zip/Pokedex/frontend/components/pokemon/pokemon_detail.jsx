import React from 'react';

export default class PokemonDetail ex
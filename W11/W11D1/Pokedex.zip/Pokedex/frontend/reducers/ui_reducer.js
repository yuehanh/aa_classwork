

const uiReducer = (state = {}, action) => {
    Object.freeze(state);
    let nextState = {};

    switch (action.type) {
        default:
        return state;
    }
};

export default uiReducer;